package com.cursosansolis.consumirws

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val email = findViewById<EditText>(R.id.txtEmailLogin)
        val password = findViewById<EditText>(R.id.txtPasswordLogin)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnRegistro = findViewById<Button>(R.id.btnIrRegistro)

        // ✅ URL confirmada
        val url = "http://10.0.2.2/Supermercado/api/login.php"
        val queue = Volley.newRequestQueue(this)

        btnLogin.setOnClickListener {
            val correo = email.text.toString().trim()
            val clave = password.text.toString().trim()

            if (correo.isEmpty() || clave.isEmpty()) {
                Toast.makeText(this, "Llena todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // ✅ Campo corregido a "password"
            val json = JSONObject()
            json.put("email", correo)
            json.put("password", clave)

            val request = JsonObjectRequest(
                Request.Method.POST, url, json,
                { response ->
                    try {
                        if (response.getBoolean("success")) {
                            val nombre = response.getString("nombre")
                            Toast.makeText(this, "Bienvenido $nombre", Toast.LENGTH_LONG).show()

                            val intent = Intent(this, MainActivity::class.java)
                            startActivity(intent)
                            finish()
                        } else {
                            val msg = response.optString("message", "Credenciales incorrectas")
                            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Toast.makeText(this, "Error procesando respuesta", Toast.LENGTH_SHORT).show()
                    }
                },
                { error ->
                    error.printStackTrace()
                    val status = error.networkResponse?.statusCode ?: "sin código"
                    Toast.makeText(this, "Error de red: $status", Toast.LENGTH_LONG).show()
                }
            )

            queue.add(request)
        }

        btnRegistro.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
    }
}
