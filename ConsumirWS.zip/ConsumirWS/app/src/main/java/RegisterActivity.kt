package com.cursosansolis.consumirws

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val nombre = findViewById<EditText>(R.id.txtNombre)
        val email = findViewById<EditText>(R.id.txtEmail)
        val password = findViewById<EditText>(R.id.txtPassword)
        val rol = findViewById<EditText>(R.id.txtRol)
        val btn = findViewById<Button>(R.id.btnRegistrar)

        val url = "http://10.0.2.2/Supermercado/api/guardarUsuario.php"
        val queue = Volley.newRequestQueue(this)

        btn.setOnClickListener {
            val json = JSONObject()
            json.put("nombre", nombre.text.toString())
            json.put("email", email.text.toString())
            json.put("password", password.text.toString())
            json.put("rol", rol.text.toString())

            val request = JsonObjectRequest(
                Request.Method.POST, url, json,
                {
                    Toast.makeText(this, "Usuario registrado", Toast.LENGTH_SHORT).show()
                    finish() // Te regresa al login
                },
                { error ->
                    Toast.makeText(this, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            )

            queue.add(request)
        }
    }
}
