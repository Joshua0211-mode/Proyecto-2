package com.cursosansolis.consumirws

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val txtIdConsulta = findViewById<EditText>(R.id.txtIdConsulta)
        val txtUser = findViewById<EditText>(R.id.txtUser)
        val txtTitle = findViewById<EditText>(R.id.txtTitle)
        val txtPrecio = findViewById<EditText>(R.id.txtPrecio)
        val txtStock = findViewById<EditText>(R.id.txtStock)
        val txtCategoriaId = findViewById<EditText>(R.id.txtCategoriaId)
        val txtBody = findViewById<EditText>(R.id.txtBody)
        val btnEnviar = findViewById<Button>(R.id.btnEnviar)
        val btnConsultar = findViewById<Button>(R.id.btnConsultar)
        val btnLimpiar = findViewById<Button>(R.id.btnLimpiar)

        val queue = Volley.newRequestQueue(this)

        // 🟢 Guardar producto
        btnEnviar.setOnClickListener {
            val json = JSONObject()
            json.put("nombre", txtUser.text.toString())
            json.put("descripcion", txtTitle.text.toString())
            json.put("precio", txtPrecio.text.toString())
            json.put("stock", txtStock.text.toString())
            json.put("categoria_id", txtCategoriaId.text.toString())
            json.put("activo", txtBody.text.toString())

            val urlGuardar = "http://10.0.2.2/Supermercado/api/guardarProducto.php"

            val request = JsonObjectRequest(
                Request.Method.POST, urlGuardar, json,
                { Toast.makeText(this, "¡Registro exitoso!", Toast.LENGTH_LONG).show() },
                { error -> Toast.makeText(this, "Error: ${error.message}", Toast.LENGTH_LONG).show() }
            )

            queue.add(request)
        }

        // 🔍 Consultar producto
        btnConsultar.setOnClickListener {
            val id = txtIdConsulta.text.toString().trim()
            if (id.isEmpty()) {
                Toast.makeText(this, "Ingresa un ID", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val params = JSONObject()
            params.put("id", id)

            val urlConsultar = "http://10.0.2.2/Supermercado/api/consultarProducto.php"

            val request = object : JsonArrayRequest(
                Method.POST, urlConsultar, null,
                Response.Listener { response ->
                    if (response.length() > 0) {
                        val obj = response.getJSONObject(0)
                        txtUser.setText(obj.getString("nombre"))
                        txtTitle.setText(obj.getString("descripcion"))
                        txtPrecio.setText(obj.getString("precio"))
                        txtStock.setText(obj.getString("stock"))
                        txtCategoriaId.setText(obj.getString("categoria_id"))
                        txtBody.setText(obj.getString("activo"))
                        Toast.makeText(this, "Consulta exitosa", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Producto no encontrado", Toast.LENGTH_SHORT).show()
                    }
                },
                Response.ErrorListener { error ->
                    error.printStackTrace()
                    Toast.makeText(this, "Error al consultar", Toast.LENGTH_LONG).show()
                }
            ) {
                override fun getBody(): ByteArray {
                    return params.toString().toByteArray(Charsets.UTF_8)
                }

                override fun getHeaders(): MutableMap<String, String> {
                    val headers = HashMap<String, String>()
                    headers["Content-Type"] = "application/json"
                    return headers
                }
            }

            queue.add(request)
        }

        // 🧼 Limpiar campos
        btnLimpiar.setOnClickListener {
            txtIdConsulta.text.clear()
            txtUser.text.clear()
            txtTitle.text.clear()
            txtPrecio.text.clear()
            txtStock.text.clear()
            txtCategoriaId.text.clear()
            txtBody.text.clear()
        }
    }
}
